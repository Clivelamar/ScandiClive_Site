<?php

class DatabaseConfig
{
    private $db_name = 'id20647580_scandiclive';
    private $password = 'FuzzeeD@123$';
    private $username = 'id20647580_scandiclive_user';
    private $host = 'localhost';
    public $connection;

    function __construct()
    {
        $this->connection = new mysqli($this->host, $this->username, $this->password, $this->db_name);
    }

    function create_table($drop_table = false)
    {
        $drop_query = "DROP TABLE IF EXISTS products";
        $drop_result = true;
        if($drop_table){
            $drop_result = mysqli_query($this->connection, $drop_query);
        }

        $create_query = "CREATE TABLE IF NOT EXISTS products(
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            sku VARCHAR(30) NOT NULL UNIQUE,
            name VARCHAR(30) NOT NULL,
            price VARCHAR(50) NOT NULL,
            productType ENUM('DVD', 'Book', 'Furniture'),
            size INT DEFAULT NULL,
            height INT DEFAULT NULL,
            width INT DEFAULT NULL,
            length INT DEFAULT NULL,
            weight INT DEFAULT NULL
        )";


        $result = mysqli_query($this->connection, $create_query);
        echo mysqli_error($this->connection);

        if ($result && $drop_result) {
            return true;
        }
        return false;
    }

}