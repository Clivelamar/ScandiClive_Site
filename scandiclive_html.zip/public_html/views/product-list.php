<?php
require_once './models/product.php';
$product = new Product;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);

    $result = $product->buik_delete($body);

    if ($result == 'success') {
        echo json_encode(array('message' => 'Products Deleted successfully'));
    } else {
        http_response_code(400);
        echo json_encode(array("error" => $result));
    }

    return;
}
$products = $product->all();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"
        integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
    <script src="../css_js/script.js"></script>
    <link rel="stylesheet" href="../css_js/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>
    <div class="wrapper container pt-4 pb-5">
        <div class="pb-3">
            <div class="form-header row align-items-center">
                <h1 class="col-sm-6">Product List</h1>
                <div class="buttons col-sm-6 text-end">
                    <button onclick="window.location.href = '/add-product'" class="btn btn-primary" type="button">ADD</button>
                    <button onclick=" deleteProduct();" class="btn btn-danger" type="button" id="delete-product-btn">MASS DELETE</button>
                </div>
            </div>
            <hr />
            <div class="products-container">
                <div class="row justify-content-center">
                    <?php
                    foreach ($products as $key => $prod) {
                        ?>
                        <div class="col-lg-3 col-md-6 product-card">
                            <div class="card mb-2">
                                <div class="card-header bg-white">
                                    <input class="form-check-input border border-primary delete-checkbox" type="checkbox"
                                        value="<?= $prod->sku ?>">
                                </div>
                                <div class="card-body text-center">
                                    <p class="card-text">
                                        <?= $prod->sku ?>
                                    </p>
                                    <p class="card-text">
                                        <?= $prod->name ?>
                                    </p>
                                    <p class="card-text">
                                        <?= $prod->price ?> $
                                    </p>
                                    <?php
                                    switch ($prod->productType) {
                                        case 'Book':
                                            echo 'Weight: ' . $prod->weight . ' KG';
                                            break;

                                        case 'DVD':
                                            echo 'Size: ' . $prod->size . ' MB';
                                            break;

                                        case 'Furniture':
                                            echo 'Dimension: ' . $prod->height . ' x ' . $prod->width . ' x ' . $prod->length;
                                            break;

                                        default:
                                            break;
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    <?php require_once 'footer.php' ?>
</body>
</html>