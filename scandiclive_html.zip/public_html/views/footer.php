<footer class="container fixed-bottom bg-white">
    <hr class="mt-1" />
    <p class="lead text-center">Scandiweb Test Assignment</p>
</footer>