<?php
// create database table
include_once './db/database.php';

//  $DBConfig = new DatabaseConfig();

// if (!$DBConfig->create_table(true)) {
//      echo "An error occured while creating table";
//  }


switch ($_SERVER['REQUEST_URI']) {
    case '/':
        include_once './views/product-list.php';
        break;

    case '/add-product':
        include_once './views/add-product.php';
        break;

    default:
        echo '<h1>Page does not exits</h1>';
        break;
}