$(document).ready(() => {
    const alertBox = $("#alert-box");
    const productForm = $("#product_form");

    let productSKUs = [];

    const productCheckbox = $('.delete-checkbox');
    productCheckbox.on('change', (e) => {
        if (e.target.checked) {
            productSKUs.push(e.target.value);
        } else {
            productSKUs = productSKUs.filter((sku) => sku != e.target.value)
        }
    })

    // delete product
    function deleteProduct() {
        if (productCheckbox.length == 0) {
            return
        }

        for (let i = 0; i < productCheckbox.length; i++) {
            if (productCheckbox[i].checked) {
                productCheckbox[i].parentElement.parentElement.remove()
            }
        }

        $.ajax({
            method: 'POST',
            url: '/',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(productSKUs),
            dataType: 'json',
            success: function (res) {
                window.location.href = "/"
            },
            error: function (XMLHttpRequest) {
                alert(XMLHttpRequest?.responseJSON?.error)
            }
        })
    }

    // watch changes on productType
    $('#productType').on('change', function () {
        let productType = $(this).val();
        $(".type-specific").hide();
        if (productType)
            $(`#${productType}`).show();
    });

    // add eventlistener to productform
    productForm.on('submit', function (e) {
        // prevent browser from reloading
        e.preventDefault()

        // hide alert box
        alertBox.hide()

        // change move value of lenght to _lenght
        this.elements._length = $('#length')[0];

        // validate form
        validatorForm(this)
    })

    // form validation
    function validatorForm(fm) {
        if (!fm.elements.sku.value || !fm.elements.name.value || !fm.elements.price.value || !fm.elements.productType.value) {
            alertBox.text("Please, submit required data");
            alertBox.show()
        } else if (isNaN(fm.elements.price.value)) {
            alertBox.text("Please, provide the data of indicated type");
            alertBox.show()
        } else if (validateProductType(fm)) {
            // save data
            $.ajax({
                method: 'POST',
                url: '/add-product',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({
                    sku: fm.elements.sku.value,
                    name: fm.elements.name.value,
                    price: fm.elements.price.value,
                    productType: fm.elements.productType.value,
                    size: fm.elements.size.value ?? null,
                    height: fm.elements.height.value ?? null,
                    width: fm.elements.width.value ?? null,
                    length: fm.elements._length.value ?? null,
                    weight: fm.elements.weight.value ?? null
                }),
                dataType: 'json',
                success: function (res) {
                    window.location.href = "/"
                    // console.log(res)
                },
                error: function (XMLHttpRequest) {
                    console.log(XMLHttpRequest.responseJSON.error);
                    alertBox.html(XMLHttpRequest.responseJSON.error);
                    alertBox.show()
                }
            })
        }
    }

    // validate product type
    function validateProductType(fm) {
        let valid = true
        const checkValues = (values) => {
            for (let i = 0; i < values.length; i++) {
                if (!values[i].value) {
                    alertBox.text("Please, submit required data");
                    alertBox.show()
                    valid = false
                } else if (isNaN(values[i].value)) {
                    alertBox.text("Please, provide the data of indicated type");
                    alertBox.show()
                    valid = false
                }
            }
        }

        switch (fm.elements.productType.value) {
            case 'DVD':
                checkValues([fm.elements.size])
                break;
            case 'Furniture':
                checkValues([fm.elements.height, fm.elements.width, fm.elements._length])
                break;
            case 'Book':
                checkValues([fm.elements.weight])
                break;
            default:
                break;
        }

        return valid
    }

    // hide alert box on click
    alertBox.on('click', () => {
        alertBox.hide()
    })

    // export delete product 
    window.deleteProduct = deleteProduct;
})