<?php

class Product
{
    private $connection;
    private $table = 'products';

    public $sku;
    public $name;
    public $price;
    public $productType;
    public $size;
    public $width;
    public $length;
    public $height;
    public $weight;


    public function __construct($result = array())
    {
        $db = new DatabaseConfig;
        $this->connection = $db->connection;

        if (!empty($result)) {
            $this->map_data($result);
        }
    }

    private function map_data($result)
    {
        $this->sku = $result['sku'];
        $this->name = $result['name'];
        $this->price = $result['price'];
        $this->productType = $result['productType'];
        $this->size = $result['size'];
        $this->height = $result['height'];
        $this->width = $result['width'];
        $this->length = $result['length'];
        $this->weight = $result['weight'];
    }

    public function save_product()
    {
        $query = "";

        if (!empty($this->get_by_sku())) {
            return 'sku <b>' . $this->sku . '</b> already exists';
        }

        switch ($this->productType) {
            case 'DVD':
                $query = "INSERT INTO $this->table (sku, name, price, productType, size) VALUES ('$this->sku', '$this->name', '$this->price', '$this->productType', '$this->size')";
                break;
            case 'Furniture':
                $query = "INSERT INTO $this->table (sku, name, price, productType, height, width, length) VALUES ('$this->sku', '$this->name', '$this->price', '$this->productType', '$this->height', '$this->width', '$this->length')";
                break;
            case 'Book':
                $query = "INSERT INTO $this->table (sku, name, price, productType, weight) VALUES ('$this->sku', '$this->name', '$this->price', '$this->productType', '$this->weight')";
                break;
            default:
                break;
        }

        $result = mysqli_query($this->connection, $query);

        if ($result) {
            return 'success';
        }

        return mysqli_error($this->connection);
    }

    public function all()
    {
        $query = "Select * from $this->table ORDER BY id DESC";
        $result = mysqli_query($this->connection, $query);
        $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);

        $products = array();
        foreach ($rows as $key => $values) {
            $products[$key] = new Product($values);
        }

        return $products;
    }

    public function get_by_sku()
    {
        $query = "Select * from $this->table Where sku = '$this->sku'";
        $result = mysqli_query($this->connection, $query);
        return mysqli_fetch_assoc($result);
    }

    public function buik_delete($ids){
        $skus = implode("','", $ids);

        $query = "DELETE FROM $this->table WHERE sku IN ('".$skus."')";
        $result = mysqli_query($this->connection, $query);

        if($result){
            return 'success';
        }else{
            return mysqli_error($this->connection);
        }
    }
}